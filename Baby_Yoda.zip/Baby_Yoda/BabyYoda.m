clear
close all
clc
%% Code Author
% Keyvon Rashidi
%% Disclaimer
% Images and  audio samples used in this code are for educational purposes only!!
% 
% FAIR USE
% 
% Copyright Disclaimer under section 107 of the Copyright Act 1976, allowance is made for ?fair use? for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research.
% 
% Fair use is a use permitted by copyright statute that might otherwise be infringing.
% 
% Non-profit, educational or personal use tips the balance in favor of fair use.
%% Load image
[y, Fs] = audioread('Star_Wars.mp3');
player = audioplayer(y, Fs);
disp('F5 pReSs It YoU mUsT...')
keyboard
im = imread('babyyoda.jpg');
im2d = rgb2gray(im);
a = double(im2d).^(double(1)/2);
set(gcf, 'Position',  [500, 100, 1000, 4000])%Modify this to adjust figure size/location 
s = surf(a,'edgecolor','none');
ylim([0 330])
grid off
tend = 300;
dt = 1;
t= 0;
while t<=tend
    if t<50
        colormap pink
        title('Pink')
    elseif t>=50 && t<100
        colormap bone
        title('Bone')
    elseif t>=100 && t<150
      colormap spring
        title('Spring')
    elseif t>=150 && t<200
        colormap summer
        title('Summer')
    elseif t>=200 && t<250
        colormap autumn
        title('Autumn')
    elseif t>=250 && t<300
        play(player);
        colormap parula
        title('Parula')
    end
    xlim([0 t+5])
    xlim([0 t+5])
    pause(0.01)
    t = t+dt;
    view(180*(t/301),90*(t/301))
end
colormap winter
title('Baby Yoda :)')
xlabel('wItH yOu tHe FoRcE MaY bE  ')
pause(16)
stop(player);